<div id='nextgen_pro_upgrade_page' class='pro'>
    <h1><?php echo $headline; ?></h1>

    <hr/>

    <h2><?php echo $description; ?></h2>

    <a href='http://www.nextgen-gallery.com/nextgen-pro' target='_blank' class="button-primary">
        Learn More About NextGEN Pro
    </a>

</div>
