<?php if ($wrap) { ?><table><?php } ?>
	<?php foreach($fields as $field): ?>
	    <?php echo $field ?>
	<?php endforeach ?>
<?php if ($wrap) { ?></table><?php } ?>